Delivery package: HL_0430

Verdict at sign-off: Needs changes first
5 things to resolve before this goes on a paid job: 2 confirmations, information to find, a licence to buy and a model or pack to swap. Each one names what lifts it.
Delivered as an exception: Upscaler swap is booked for the next pass; delivering this version for the client review.


What is in here
- HL_0430.json: The ComfyUI workflow. Its shot history (extra.comfyaudit_history) is
  hash-chained and, when the studio key is set, signed. The sign-off entry carries the
  clearance, sealed.
- HL_0430.legal-report.html: The provenance record for legal: clearance, who did what
  and when, models over time, prompt authorship, sources, the rules checklist.
- HL_0430.licence-audit.html: The full licence and risk audit behind the verdict: every
  model and node pack, its licence, what the licence allows for this studio, and the
  risk score.
- HL_0430.life.html: The shot's life on one timeline: the graph as it stood at each
  entry, the story and the log. Opens in any browser, offline.
- HL_0430.omc.json: The same history as MovieLabs OMC-JSON v2.8 entities, for studio
  asset systems.
- HL_0430.c2pa.json: A C2PA manifest definition for the delivered file, unsigned;
  renders signed with it are under signed/.
- HL_0430.package.json: the index of this package for software and agents: the
  decision, what is outstanding, and every file with its SHA-256. Each HTML file also
  carries its data as JSON in <script id='comfyaudit-data'>.

Left for legal to confirm (76): production facts nobody in the workflow has
attested. Each is also in the legal report under the rule it belongs to; record
each one in the shot's history once it is confirmed.

[ ] C2PA Content Credentials + IPTC digital source types (Global)
    - Where used: a c2pa.ai-disclosure assertion naming the model(s) and the human oversight level
[ ] 2023 TV/Theatrical: employment-based digital replicas (Industry)
    - Signed/initialed digital replica consent rider with the use description, linked to the shot/asset IDs it covers
    - Notice timestamp showing 48-hour notice for scan/capture sessions
    - Mapping of replica-generated shots to the consented project and use description
    - Payment calculation records for replica-generated scenes
[ ] 2023 TV/Theatrical: independently created replicas and digital alteration (Industry)
    - Classification of each AI alteration as routine post (exempt) or beyond script/performance (consent needed)
    - Consent document or estate/union authorization
[ ] 2023 TV/Theatrical: synthetic performers (Industry)
    - Record of union notice for synthetic human characters
    - Prompt/reference-image log showing no real performer's features were used to generate the character (or consent if they were)
[ ] 2026 TV/Theatrical Agreement AI terms (Industry)
    - Scan-request record with the stated business reason, consent, and the performer's or background actor's identity
    - Replica asset register: source footage or scan, creation date, holder, people with access, access log, and security measures
    - Transfer record for any replica that changes hands, with union approval and the transferee's written undertaking
    - Consent records tied to each replica use, including dubbing consents for pictures starting principal photography on or after 2027-07-01
    - The script version (and date given to the performer) used to judge whether an alteration was within what was scripted
    - Flag on any replica or shot involving a minor, with confirmation that no nude or sexual depiction (including age-shifting) was generated
    - Synthetic-use file: union notice, bargaining record, and the 'significant additional value' justification per role
    - Record that biometric identifiers were not used outside the picture
    - Union notice and license record for any sale of performance data for AI training
[ ] DGA Basic Agreement AI terms (2023 and 2026) (Industry)
    - Record that the director (or other DGA-covered employee) was consulted on each generative-AI creative element, with date and outcome
    - Record of any licensing of production footage for AI training
[ ] Allen v. Perlmutter (Théâtre D'opéra Spatial) (US)
    - Separate before/after versions of human paint/comp edits, so they can be claimed apart from the generated base
    - Record of upscalers or enhancers used (e.g. Gigapixel AI) and whether they add new content
[ ] Andersen v. Stability AI, Midjourney, DeviantArt and Runway (US)
    - Prompt log screened for living artists' names used as style cues
[ ] Copyright and AI, Part 2: Copyrightability (US)
    - Record of human modifications after generation (comp, paint, roto, grading) with before/after versions
[ ] Getty Images v. Stability AI (N.D. Cal.) (US)
    - QC for watermarks and logos in outputs
    - Vendor licence and indemnity terms for Stability models
[ ] NO FAKES Act (US)
    - Likeness/voice licences, which already exist under state law practice
[ ] AG Munich 142 C 9786/25: AI-generated logos not protected (EU)
    - Full prompt and iteration history, together with evidence that specific human choices determine specific visual features
    - Human-made inputs and edits beyond selection (sketches, layouts, paintovers)
[ ] AI Act Art. 50(2): machine-readable marking of synthetic output (EU)
    - Whether the studio acts as a provider (own or modified generative system put into service under its name, including in-house) or only as a deployer of third-party tools, with the reasoning
    - Per AI operation: classification as standard editing (exempt) or substantive alteration (marking required), referencing the guidelines' examples
    - Marking method applied per final output (signed metadata / C2PA manifest, watermark), and verification that it survives the delivery pipeline
    - Vendor contract terms guaranteeing marking by upstream system providers
[ ] AI Act Art. 50(4): deepfake disclosure by deployers (EU)
    - Per-deliverable flag: contains a realistic AI-generated or manipulated depiction of real-seeming persons, places or events (Y/N), with the reasoning (VFX/background vs. digital replica, de-aging, synthetic performer)
    - Whether the evidently-artistic/fictional regime was relied on, and why (format, distribution context, audience expectations)
    - Disclosure method and placement used (on-screen icon, opening notice, end credits, spoken disclaimer) and the territories where the work was distributed
    - Contract terms with distributors that keep the label displayed at first exposure
    - Consent and rights clearances for real persons depicted
[ ] AI Act Art. 53: general-purpose AI model providers must publish a training-data summary and keep a copyright policy (EU)
    - For each model/checkpoint used in a shot: the provider's identity
    - Whether the provider publishes a training-data summary on the Commission template (link and date)
    - Whether the provider publishes a copyright policy (link), and whether it is a GPAI Code of Practice signatory for the Transparency and Copyright chapters
    - For open-weight or community models: whether the model is above the GPAI threshold and whether any summary/policy exists; flag unknown-provenance fine-tunes and LoRAs
    - For studio fine-tunes: training compute relative to the base model, and the studio's own dataset records
[ ] Code of Practice on Transparency (marking and labelling) of AI-generated content (EU)
    - Whether the studio (and each tool vendor) is a Code signatory
    - Labelling SOP and record of the label/icon applied per deliverable, with placement and repetition for long-form video
    - Provenance metadata retained through delivery
    - Training/awareness records for staff who approve labelling, and the channel for correcting labels
[ ] Commission Guidelines on AI Act Art. 50 transparency, C(2026) 5054: film and VFX treatment (EU)
    - Per shot: AI operations performed and their classification (standard edit / substantive alteration / generation)
    - Per deliverable: deepfake assessment (VFX/background vs. replica, de-aging, synthetic performer), and whether the artistic/fictional regime is relied on
    - Disclosure placement and timing for each distributed version
    - Which party (studio, vendor, client) decided and controlled the AI use
[ ] GEMA v OpenAI (42 O 14139/24) (EU)
    - Output similarity checks against known third-party IP for final deliverables
[ ] General-Purpose AI Code of Practice (Transparency, Copyright, Safety & Security chapters): signatory status (EU)
    - Per model used: provider's signatory status on the Commission list (checked on date X), and which chapters
    - Signatories listed on 2026-10-07: AI Studio Delta, Aleph Alpha, Almawave, Amazon, Anthropic, Black Forest Labs, Bria AI, Cohere, Domyn, Dweve, Fastweb, Google, IBM, LINAGORA, Microsoft, Mistral AI, Open Hippo, OpenAI, Pleias, Reflection AI, ServiceNow, WRITER, xAI (Safety and Security only)
[ ] Originality = author's own intellectual creation (Infopaq C-5/08; Painer C-145/10; Mio/konektra C-580/23 & C-795/23) (EU)
    - Records of human creative choices visible in the final frame: composition, framing, lighting, layout, paintovers, edit decisions
    - Link between those choices and the output (e.g. control images, masks, comp scripts)
[ ] MPA Content Security Best Practices v5.3.2: AI Supplemental v1.0 (AI/ML controls) (Global (industry standard; contractual for vendors to MPA member studios))
    - Per-project written client approval of each AI tool or service used on client content
    - Approved AI tool inventory/SBOM entry for every node pack, model, LoRA and API used, with version, source and approval status
    - Data-handling terms for any third-party AI API (no training, retention period, tenant isolation)
    - Written client consent if client content was used to train or fine-tune (e.g. a LoRA trained on plates)
[ ] AB 1836: digital replicas of deceased personalities (US-CA)
    - Estate consent, or a documented exemption analysis, for any deceased person's likeness or voice
[ ] AB 2602: unenforceable digital replica contract terms (US-CA)
    - Contract clause with a reasonably specific use description
    - Proof of counsel or union representation
    - Map of replica-generated shots to the contracted uses
[ ] Living-person right of publicity covers digital replicas (US-CA)
    - Signed consent or licence for any living person's voice or likeness used in ads or merchandise, including AI replicas
    - For employee likeness in marketing, a signed release (the presumption no longer applies after 2027-01-01)
[ ] Illinois Digital Voice and Likeness Protection Act (contract terms) (US-IL)
    - Contract clause with a reasonably specific replica-use description
    - Proof of counsel or union representation
    - Map of replica-generated shots to the contracted uses
[ ] Illinois Right of Publicity Act: unauthorized digital replicas (US-IL)
    - Consent from the depicted individual or rights holder for every real-person replica in a released work
    - For documentary or biographical uses: note why the replica does not create a false impression of authentic participation
[ ] New York digital replica contract law (US-NY)
    - Same as California AB 2602: use description plus proof of representation
[ ] Post-mortem right of publicity and deceased-performer replicas (US-NY)
    - Rights-holder consent, or an exemption analysis
[ ] ELVIS Act (voice and likeness) (US-TN)
    - Authorization for any sound-alike or look-alike, including AI voices 'in the style of' a person
[ ] Washington personality rights: forged digital likeness (US-WA)
    - Consent for any real person whose likeness or voice is synthesized
    - Exemption analysis for satire, parody or commentary uses

Answered once for the show or studio, and relied on here (1). Each is
sealed in the sign-off with its signature, so it holds without the studio's records.

[x] mpa-tpn-content-security-ai-controls:3 - studio: Model intake log MI-2026: every model scanned and its SHA-256 recorded before it entered the content network (Jo Okonkwo, 2026-10-16)

Check the history: comfyaudit history verify <workflow.json> (with the studio key and
ledger set). This package was produced by an automated tool; it is evidence to take
to counsel, not legal advice.
